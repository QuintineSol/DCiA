Welcome to snaG7!

## PACKAGE STRUCTURE
- **DESCRIPTION file:** Contains metadata about the package.
- **NAMESPACE file:** Specifies which functions to export (i.e., tells R which functions to make available to package users).
- **R/ directory:** Contains R script files with functions.
- **inst/ directory:** Contains any additional files needed for the package: extdata/ and tutorials/.
- **man/ directory:** Contains documentation files (.Rd files provide documentation for each exported function).

### (optional)
- **tests/ directory:** Contains test scripts.
- **data/ directory:** Contains datasets that are included with our package.
- **vignettes/ directory:** Contains longer-form documents that provide detailed explanations, tutorials, or use cases for our package.

## Structure
```
snaG7/
├── DESCRIPTION
├── NAMESPACE
├── R/
│   ├── tutorials.R
|   ├── solve_imports.R
│   └── load_network.R
├── man/
│   ├── T0.Rd
│   ├── solve_imports.Rd
│   └── load_network.Rd
├── inst/
|   ├── tutorials/
│   │   ├── learnrDraft1.Rmd
│   │   └── learnrDraft1.html
|   └── extdata/
│       └── Attribute_table_Final.xlsx
├── data/
│   ├── networks.RData
│   ├── knowledge_sharing_people_to_people.csv
│   ├── graphs.RData
│   ├── grants_people_to_people.csv
│   ├── grants_people_to_grant_application.csv
│   ├── explanations.Rdata
│   └── co_authorship_people_to_people.csv
├── tests/
│   ├── testthat.R
|   └── testthat/
│       └── test-load_network.R
└── README.md
```
