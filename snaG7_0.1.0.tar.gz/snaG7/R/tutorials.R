#' Launch the Tutorial
#'
#' Launches the learnr tutorial included in the package.
#' 
#' @export
#' 
#' @examples
#' \dontrun{
#' snaG7::T0()
#' }
T0 <- function() {
  learnrDraft1 <- system.file("tutorials", "learnrDraft1.Rmd", package = "snaG7")
  if (file.exists(learnrDraft1)) {
    learnr::run_tutorial(learnrDraft1)
  } else {
    stop("Tutorial file not found.")
  }
}

