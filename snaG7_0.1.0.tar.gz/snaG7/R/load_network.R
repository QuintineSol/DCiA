############################### tags signal to roxygen2 ########################

#' Load Network
#'
#' This function takes a network-like object and returns an object of type either network or igraph.
#' The input can be an igraph object, a network object, an edge list, an incidence matrix, or an adjacency matrix.
#'
#' @param network The network-like object to be converted.
#' @param output The type of output object, either 'network' or 'igraph'. Default is 'network'.
#' @param vlist Optional. A list of all vertices, required when providing an edge list.
#' @param directed Whether the network is directed. Default is FALSE (undirected).
#' @return A network or igraph object depending on the output parameter.
#' @export

load_network = function(network, output = 'network', vlist = NULL, directed = F){
  # The load network function takes a network-like object and returns an attribute with a network object
  #
  # The network input can be defined in mutiple different ways:
  # - An igraph object
  # - A network object
  # - An edge list (Defined as a matrix with size x, 2) and optional vertex list
  # - An incidence matrix (if its a matrix with size n, m)
  # - An adjacency matrix (if its a matrix with size n, n)
  #
  # There multiple different parameters which can be defined:
  # output: Defines which output is generated. Can be either network' (default) or 'igraph'
  # vlist (optional): List of all vertices to provide when providing an edge list
  # directed (optional): Whether the network is directed or not (default is undirected)
  
  # Construct the path to the data file
  data_file <- system.file('data', paste0(network, '.csv'), package = 'snaG7')
  
  # Load the network data from the file
  network_data <- utils::read.csv(data_file)
  
  if (snafun::is_igraph(network)){
    # igraph
    if (output == 'network'){
      return(snafun::to_network(network))
    } else if (output == 'igraph'){
      return(network)
    }
  }else if (snafun::is_network(network)){
    #network
    if (output == 'network'){
      return(network)
    } else if (output == 'igraph'){
      return(snafun::to_igraph(network))
    }
  }else if (class(network)[1]=='matrix'){
    if (dim(network)[1] == dim(network)[2]){
      if (all(t(network) == network)){
        # Undirected Adjacency matrix
        if (output == 'network'){
          return(snafun::to_network(igraph::graph_from_adjacency_matrix(network, mode = 'undirected', diag = FALSE)))
        } else if (output == 'igraph'){
          return(igraph::graph_from_adjacency_matrix(network, mode = 'undirected', diag = FALSE))
        }
      } else {
        # Directed Adjacency matrix (nxn)
        if (output == 'network'){
          return(snafun::to_network(igraph::graph_from_adjacency_matrix(network, mode = 'directed', diag = FALSE)))
        } else if (output == 'igraph'){
          return(igraph::graph_from_adjacency_matrix(network, mode = 'directed', diag = FALSE))
        }
      }
    } else if (dim(network)[2] == 2){
      # edge list
      bipartite = length(intersect(network[,1], network[,2])) == 0
      if (bipartite){
        net = igraph::graph_from_data_frame(network, directed = directed)
        igraph::V(net)$type = ifelse(igraph::V(net)$name %in% network[,1], 
                                     yes = FALSE, no = TRUE
        ) # Create bipartite division between the nodes
        if (output == 'network'){
          return(snafun::to_network(snafun::to_matrix(net), bipartite = T))
        } else if (output == 'igraph'){
          return(net)
        }
      } else {
        if (output == 'network'){
          return(snafun::to_network(igraph::graph_from_data_frame(network, directed = directed, vertices = vlist)))
        } else if (output == 'igraph'){
          return(igraph::graph_from_data_frame(network, directed = directed, vertices = vlist))
        }
      }
    } else{
      # Incidence matrix (mxn)
      if (output == 'network'){
        return(snafun::to_network(igraph::graph_from_incidence_matrix(network, directed = directed, mode = 'out'), bipartite = T))
      } else if (output == 'igraph'){
        return(igraph::graph_from_incidence_matrix(network, directed = directed, mode = 'out'))
      }
    }
  }
}
