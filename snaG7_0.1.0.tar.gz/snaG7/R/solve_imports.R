############################### tags signal to roxygen2 ########################

#___________________________ as found in sna4tutti _____________________________

# This is a hack to make the warnings disappear for packages that are used 
# inside chunks. For these packages, the 'check' function does not understand 
# that they are required, and hence complains about them being mentioned in 
# the "Imports" section of the NAMESPACE.
# The hack is simple: just call the packages here, once, so they are indeed 
# used outside of a chunk.


#' Solve Imports
#'
#' This function ensures that the necessary packages are loaded and used outside of R code chunks.
#'
#' @return NULL
#' 
#' @export
solve_imports <- function() {
  # Call functions from required packages to ensure they are used
  hack <- gradethis::code_feedback
  hack <- igraph::add.edges
  hack <- learnr::answer
  hack <- network::add.edge
  hack <- tsna::as.network.tPath
  # Remove the temporary variables to avoid cluttering the environment
  rm(hack)
}
